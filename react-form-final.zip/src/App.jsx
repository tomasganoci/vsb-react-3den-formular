import React, { useState, useEffect } from "react"
import "./App.css"
import validateFloat from "./functions/validateFloat"
import RbGroup from "./components/RbGroup"
import ChbGroup from "./components/ChbGroup"
import NumImp from "./components/NumImp"
import Select from "./components/Select"
import Range from "./components/Range"
import Clock from "./components/Clock"
import ProgressBar from "./components/ProgressBar"
import TextBox from "./components/TextBox"
import Button from "./components/Button"
import TextArea from "./components/TextArea"
import File from "./components/File"
import saveText from "./functions/saveText"

function App() {
  const [scitanec1, setScitanec1] = useState("")
  const [scitanec2, setScitanec2] = useState("")
  const [prichut, setPrichut] = useState("vanilková")
  const [pridavky, setPridavky] = useState([])
  const [kopecky, setKopecky] = useState(1)
  const [druh, setDruh] = useState("jogurtová")
  const [disk, setDisk] = useState(90)
  const initialCountDown = 20
  const [countDown, setCountDown] = useState(initialCountDown)
  const [vysledek, setVysledek] = useState(
    "Zadejte validní sčítance a zmáčkněte tlačítko výpočtu"
  )
  const [text, setText] = useState("")

  useEffect(() => {
    let temp = prompt("Zadejte hodnotu prvního sčítance.")
    while (!validateFloat(temp)) {
      temp = prompt("Zadejte hodnotu prvního sčítance.")
    }
    setScitanec1(temp)
  }, [])

  useEffect(() => {
    if (countDown > 0) {
      const timer = setInterval(() => {
        setCountDown(countDown - 1)
      }, 1000)
      return () => clearInterval(timer)
    }
  }, [countDown])

  const progress =
    countDown > 0
      ? ((initialCountDown - countDown) / initialCountDown) * 100
      : 100

  const handleData = (data, source) => {
    switch (source) {
      case "rbg-prichut":
        setPrichut(data)
        break
      case "chb-pridavek":
        setPridavky(data)
        break
      case "num-kopecky":
        if (data > 0 && data < 5) {
          setKopecky(data)
        }
        break
      case "sel-druh":
        setDruh(data)
        break
      case "rng-disk":
        setDisk(data)
        break
      case "txb-scitanec1":
        setScitanec1(data)
        break
      case "txb-scitanec2":
        setScitanec2(data)
        break
      case "txa-text":
        setText(data)
        break
      case "file-load":
        setText(data)
        break
      default:
        break
    }
  }

  const handleEvent = (source) => {
    switch (source) {
      case "btn-soucet":
        secti()
        break
      case "btn-download":
        saveText(text)
        break
      default:
        break
    }
  }

  const secti = () => {
    if (validateFloat(scitanec1) && validateFloat(scitanec2)) {
      setVysledek(`Součet je ${parseFloat(scitanec1) + parseFloat(scitanec2)}`)
    } else {
      setVysledek("Zadejte validní sčítance a zmáčkněte tlačítko výpočtu")
    }
  }

  return (
    <div className="bg-info-subtle vw-100 vh-100">
      <div className="container bg-warning-subtle">
        <div className="row">
          <div className="col-6 p-5">
            <p>
              {prichut} {kopecky} kopečky{" "}
              {pridavky.map((pridavek) => pridavek + " ")}
              {druh}
            </p>
            <div className="mt-3">
              <RbGroup
                label="Příchuť zmrzliny"
                id="rbg-prichut"
                dataIn={[
                  { label: "vanilková", value: "vanilková" },
                  { label: "čokoládová", value: "čokoládová" },
                  { label: "míchaná", value: "míchaná" },
                ]}
                handleData={handleData}
                selectedValue={prichut}
              />
            </div>
            <div className="mt-3">
              <ChbGroup
                label="Něco navíc?"
                id="chb-pridavek"
                dataIn={[
                  { label: "kousky oříšků", value: "s kousky oříšků" },
                  { label: "čoko hoblinky", value: "s čoko hoblinkami" },
                  {
                    label: "karamelové křupinky",
                    value: "s karamelovými křupinkami",
                  },
                ]}
                selectedValue={pridavky}
                handleData={handleData}
              />
            </div>
            <div className="mt-3">
              <NumImp
                label="Počet kopečků (max. 4)"
                id="num-kopecky"
                dataIn={kopecky}
                handleData={handleData}
              />
            </div>
            <div className="mt-3">
              <Select
                label="Vyberte druh zmrzliny"
                id="sel-druh"
                selectedValue={druh}
                handleData={handleData}
                dataIn={["smetanová", "jogurtová", "nízkotučná"]}
              />
            </div>
            <div className="mt-3">
              <Range
                min={0}
                max={100}
                label="Místo na disku"
                id="rng-disk"
                dataIn={disk}
                handleData={handleData}
              />
            </div>
            <div className="mt-3">
              <Clock />, zbývá {disk}% místa na disku
            </div>
          </div>
          <div className="col-6 p-5">
            <div>
              <ProgressBar id="pgb-progress" dataIn={progress} />
            </div>
            <p className="mt-3">
              Insatalace probíhá, počkejte {countDown} sekund.
            </p>
            <div className="row mt-3">
              <div className="col-6">
                <TextBox
                  label="Sčítanec 1"
                  dataIn={scitanec1}
                  id="txb-scitanec1"
                  handleData={handleData}
                />
              </div>
              <div className="col-6">
                <TextBox
                  label="Sčítanec 2"
                  dataIn={scitanec2}
                  id="txb-scitanec2"
                  handleData={handleData}
                />
              </div>
            </div>
            <div className="row mt-3">
              <div className="col-6">
                <Button
                  id="btn-soucet"
                  label="Vypočítej součet"
                  handleEvent={handleEvent}
                />
              </div>
              <div className="col-6">{vysledek}</div>
            </div>
            <div className="mt-3">
              <TextArea
                id="txa-text"
                label="Operace s textem"
                dataIn={text}
                handleData={handleData}
                height={200}
              />
            </div>
            <div className="row mt-3">
              <div className="col-6">
                <File
                  id="file-load"
                  label="Načti text ze souboru"
                  handleData={handleData}
                />
              </div>
              <div className="col-6">
                <Button
                  id="btn-download"
                  label="Stáhni soubor s textem"
                  handleEvent={handleEvent}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
